
import numpy as np
import pandas as pd


class rlalgorithm:
    def __init__(self, actions, *args, **kwargs):
        """Your code goes here"""
        pass

    def choose_action(self, observation):
        """Your code goes here"""
        pass

    def learn(self, s, a, r, s_):
        """Your code goes here"""
        pass
